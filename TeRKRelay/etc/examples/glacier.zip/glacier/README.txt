This example demonstrates the use of a Glacier2 router and the
implementation of a Glacier2 session server.

To run the demo:

Start the server:

$ java -cp .;C:\Ice-3.0.1\lib\Ice.jar;log4j-1.2.13.jar;commons-logging.jar Server

In a separate window, start the session server:

$ java -cp .;C:\Ice-3.0.1\lib\Ice.jar;log4j-1.2.13.jar;commons-logging.jar SessionServer

In a separate window, start the Glacier2 router:

$ glacier2router --Ice.Config=config.glacier2.properties

In a separate window, start the client:

$ java -cp .;C:\Ice-3.0.1\lib\Ice.jar;log4j-1.2.13.jar;commons-logging.jar Client

If you plan to run this demo using clients running on different
hosts than the glacier2router, it is necessary to first modify the
configuration. You need to change the Glacier2.Client.Endpoints
property in config.glacier2 and the Ice.Default.Router and
Callback.Client.Router properties in config. In all cases you must
replace the "-h 127.0.0.1" parameter with the actual external address
of the machine on which glacier2router is running.
