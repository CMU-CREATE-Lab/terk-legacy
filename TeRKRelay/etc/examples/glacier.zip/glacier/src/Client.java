// **********************************************************************
//
// Copyright (c) 2003-2005 ZeroC, Inc. All rights reserved.
//
// This copy of Ice is licensed to you under the terms described in the
// ICE_LICENSE file included in this distribution.
//
// **********************************************************************

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import Demo.CallbackPrx;
import Demo.CallbackPrxHelper;
import Demo.CallbackReceiverPrx;
import Demo.CallbackReceiverPrxHelper;
import Glacier2.CannotCreateSessionException;
import Glacier2.PermissionDeniedException;
import Glacier2.RouterPrx;
import Glacier2.RouterPrxHelper;
import Ice.Application;
import Ice.Identity;
import Ice.LocalException;
import Ice.ObjectAdapter;
import Ice.ObjectPrx;
import Ice.Properties;
import Ice.Util;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public final class Client extends Application
   {
   private static final Log LOG = LogFactory.getLog(Client.class);

   private static void menu()
      {
      LOG.info(
            "usage:\n" +
            "t: send callback as twoway\n" +
            "o: send callback as oneway\n" +
            "O: send callback as batch oneway\n" +
            "f: flush all batch requests\n" +
            "v: set/reset override context field\n" +
            "F: set/reset fake category\n" +
            "s: shutdown server\n" +
            "x: exit\n" +
            "?: help\n");
      }

   public int run(final String[] args)
      {
      final Ice.RouterPrx defaultRouter = communicator().getDefaultRouter();
      if (defaultRouter == null)
         {
         LOG.error("no default router set");
         return 1;
         }

      final RouterPrx router = RouterPrxHelper.checkedCast(defaultRouter);
      if (router == null)
         {
         LOG.error("configured router is not a Glacier2 router");
         return 1;
         }

      final BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
      while (true)
         {
         LOG.info("This demo accepts any user-id / password combination.");

         try
            {
            final String id;
            System.out.print("user id: ");
            System.out.flush();
            id = in.readLine();

            final String pw;
            System.out.print("password: ");
            System.out.flush();
            pw = in.readLine();

            try
               {
               router.createSession(id, pw);
               break;
               }
            catch (PermissionDeniedException ex)
               {
               LOG.error("permission denied:\n" + ex.reason);
               }
            catch (CannotCreateSessionException ex)
               {
               LOG.error("cannot create session:\n" + ex.reason);
               }
            }
         catch (IOException ex)
            {
            ex.printStackTrace();
            }
         }

      final String category = router.getServerProxy().ice_getIdentity().category;
      final Identity callbackReceiverIdent = new Identity();
      callbackReceiverIdent.name = "callbackReceiver";
      callbackReceiverIdent.category = category;
      final Identity callbackReceiverFakeIdent = new Identity();
      callbackReceiverFakeIdent.name = "callbackReceiver";
      callbackReceiverFakeIdent.category = "fake";

      final Properties properties = communicator().getProperties();
      final String proxyProperty = "Callback.Proxy";
      final String proxy = properties.getProperty(proxyProperty);
      if (proxy.length() == 0)
         {
         LOG.error("property `" + proxyProperty + "' not set");
         return 1;
         }

      final ObjectPrx base = communicator().stringToProxy(proxy);
      final CallbackPrx twoway = CallbackPrxHelper.checkedCast(base);
      final CallbackPrx oneway = CallbackPrxHelper.uncheckedCast(twoway.ice_oneway());
      final CallbackPrx batchOneway = CallbackPrxHelper.uncheckedCast(twoway.ice_batchOneway());

      final ObjectAdapter adapter = communicator().createObjectAdapter("Callback.Client");
      adapter.add(new CallbackReceiverI(), callbackReceiverIdent);
      adapter.add(new CallbackReceiverI(), callbackReceiverFakeIdent);
      adapter.activate();

      CallbackReceiverPrx twowayR = CallbackReceiverPrxHelper.uncheckedCast(adapter.createProxy(callbackReceiverIdent));
      CallbackReceiverPrx onewayR = CallbackReceiverPrxHelper.uncheckedCast(twowayR.ice_oneway());

      menu();

      String line = null;
      String override = null;
      boolean fake = false;
      do
         {
         try
            {
            System.out.print("==> ");
            System.out.flush();
            line = in.readLine();
            if (line == null)
               {
               break;
               }
            if ("t".equals(line))
               {
               final Map context = new HashMap();
               context.put("_fwd", "t");
               if (override != null)
                  {
                  context.put("_ovrd", override);
                  }
               twoway.initiateCallback(twowayR, context);
               }
            else if ("o".equals(line))
               {
               final Map context = new HashMap();
               context.put("_fwd", "o");
               if (override != null)
                  {
                  context.put("_ovrd", override);
                  }
               oneway.initiateCallback(onewayR, context);
               }
            else if ("O".equals(line))
               {
               final Map context = new HashMap();
               context.put("_fwd", "O");
               if (override != null)
                  {
                  context.put("_ovrd", override);
                  }
               batchOneway.initiateCallback(onewayR, context);
               }
            else if (!"f".equals(line))
               {
               if ("v".equals(line))
                  {
                  if (override == null)
                     {
                     override = "some_value";
                     LOG.info("override context field is now `" + override + "'");
                     }
                  else
                     {
                     override = null;
                     LOG.info("override context field is empty");
                     }
                  }
               else if ("F".equals(line))
                  {
                  fake = !fake;

                  if (fake)
                     {
                     twowayR = CallbackReceiverPrxHelper.uncheckedCast(twowayR.ice_newIdentity(callbackReceiverFakeIdent));
                     onewayR = CallbackReceiverPrxHelper.uncheckedCast(onewayR.ice_newIdentity(callbackReceiverFakeIdent));
                     }
                  else
                     {
                     twowayR = CallbackReceiverPrxHelper.uncheckedCast(twowayR.ice_newIdentity(callbackReceiverIdent));
                     onewayR = CallbackReceiverPrxHelper.uncheckedCast(onewayR.ice_newIdentity(callbackReceiverIdent));
                     }

                  LOG.info("callback receiver identity: " + Util.identityToString(twowayR.ice_getIdentity()));
                  }
               else if ("s".equals(line))
                  {
                  twoway.shutdown();
                  }
               else if ("x".equals(line))
                  {
                  // Nothing to do
                  }
               else if ("?".equals(line))
                  {
                  menu();
                  }
               else
                  {
                  LOG.error("unknown command `" + line + "'");
                  menu();
                  }
               }
            else
               {
               communicator().flushBatchRequests();
               }
            }
         catch (IOException ex)
            {
            ex.printStackTrace();
            }
         catch (LocalException ex)
            {
            ex.printStackTrace();
            }
         }
      while (!"x".equals(line));

      return 0;
      }

   public static void main(final String[] args)
      {
      final Client app = new Client();
      final int status = app.main("Client", args, "config.properties");
      System.exit(status);
      }
   }
