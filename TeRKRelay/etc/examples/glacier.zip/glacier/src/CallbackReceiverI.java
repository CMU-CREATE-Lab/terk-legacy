// **********************************************************************
//
// Copyright (c) 2003-2005 ZeroC, Inc. All rights reserved.
//
// This copy of Ice is licensed to you under the terms described in the
// ICE_LICENSE file included in this distribution.
//
// **********************************************************************

import Demo._CallbackReceiverDisp;
import Ice.Current;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public final class CallbackReceiverI extends _CallbackReceiverDisp
   {
   private static final Log LOG = LogFactory.getLog(CallbackReceiverI.class);

   public void callback(final Current current)
      {
      LOG.info("received callback");
      }
   }
