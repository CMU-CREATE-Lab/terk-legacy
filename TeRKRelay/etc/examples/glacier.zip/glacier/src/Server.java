// **********************************************************************
//
// Copyright (c) 2003-2005 ZeroC, Inc. All rights reserved.
//
// This copy of Ice is licensed to you under the terms described in the
// ICE_LICENSE file included in this distribution.
//
// **********************************************************************

import Ice.Application;
import Ice.ObjectAdapter;
import Ice.Util;

public final class Server extends Application
   {
   public int run(final String[] args)
      {
      final ObjectAdapter adapter = communicator().createObjectAdapter("Callback.Server");
      adapter.add(new CallbackI(), Util.stringToIdentity("callback"));
      adapter.activate();
      communicator().waitForShutdown();
      return 0;
      }

   public static void main(final String[] args)
      {
      final Server app = new Server();
      final int status = app.main("Server", args, "config.server.properties");
      System.exit(status);
      }
   }
