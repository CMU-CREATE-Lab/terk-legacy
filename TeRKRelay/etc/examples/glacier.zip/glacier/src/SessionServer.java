// **********************************************************************
//
// Copyright (c) 2003-2005 ZeroC, Inc. All rights reserved.
//
// This copy of Ice is licensed to you under the terms described in the
// ICE_LICENSE file included in this distribution.
//
// **********************************************************************

import Glacier2._PermissionsVerifierDisp;
import Ice.Current;
import Ice.ObjectAdapter;
import Ice.StringHolder;
import Ice.Util;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public final class SessionServer
   {
   private static final Log LOG = LogFactory.getLog(SessionServer.class);

   private static final class DummyPermissionVerifierI extends _PermissionsVerifierDisp
      {
      public boolean checkPermissions(final String userId, final String password, final StringHolder reason, final Current current)
         {
         LOG.info("verified user `" + userId + "' with password `" + password + "'");
         return true;
         }
      }

   static final class Application extends Ice.Application
      {
      public int run(final String[] args)
         {
         final ObjectAdapter adapter = communicator().createObjectAdapter("SessionServer");
         adapter.add(new DummyPermissionVerifierI(), Util.stringToIdentity("verifier"));
         adapter.add(new SessionManagerI(), Util.stringToIdentity("sessionmanager"));
         adapter.activate();
         communicator().waitForShutdown();
         return 0;
         }
      }

   public static void main(final String[] args)
      {
      final Application app = new Application();
      final int status = app.main("Server", args, "config.sessionserver.properties");
      System.exit(status);
      }

   private SessionServer()
      {
      // private to prevent instantiation
      }
   }
