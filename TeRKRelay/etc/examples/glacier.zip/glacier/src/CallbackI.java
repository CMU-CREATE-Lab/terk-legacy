// **********************************************************************
//
// Copyright (c) 2003-2005 ZeroC, Inc. All rights reserved.
//
// This copy of Ice is licensed to you under the terms described in the
// ICE_LICENSE file included in this distribution.
//
// **********************************************************************

import Demo.CallbackReceiverPrx;
import Demo._CallbackDisp;
import Ice.Current;
import Ice.LocalException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public final class CallbackI extends _CallbackDisp
   {
   private static final Log LOG = LogFactory.getLog(CallbackI.class);

   public void initiateCallback(final CallbackReceiverPrx proxy, final Current current)
      {
      LOG.info("initiating callback");
      try
         {
         proxy.callback(current.ctx);
         }
      catch (LocalException ex)
         {
         ex.printStackTrace();
         }
      }

   public void shutdown(final Current current)
      {
      LOG.info("Shutting down...");
      try
         {
         current.adapter.getCommunicator().shutdown();
         }
      catch (LocalException ex)
         {
         ex.printStackTrace();
         }
      }
   }
