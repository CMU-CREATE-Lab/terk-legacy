// **********************************************************************
//
// Copyright (c) 2003-2005 ZeroC, Inc. All rights reserved.
//
// This copy of Ice is licensed to you under the terms described in the
// ICE_LICENSE file included in this distribution.
//
// **********************************************************************

import Glacier2.Session;
import Glacier2.SessionPrx;
import Glacier2.SessionPrxHelper;
import Glacier2._SessionManagerDisp;
import Ice.Current;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public final class SessionManagerI extends _SessionManagerDisp
   {
   private static final Log LOG = LogFactory.getLog(SessionManagerI.class);

   public SessionPrx create(final String userId, final Current current)
      {
      LOG.info("creating session for user `" + userId + "'");
      final Session session = new SessionI(userId);
      return SessionPrxHelper.uncheckedCast(current.adapter.addWithUUID(session));
      }
   }
