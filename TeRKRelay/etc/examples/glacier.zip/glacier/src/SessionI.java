// **********************************************************************
//
// Copyright (c) 2003-2005 ZeroC, Inc. All rights reserved.
//
// This copy of Ice is licensed to you under the terms described in the
// ICE_LICENSE file included in this distribution.
//
// **********************************************************************

import Glacier2._SessionDisp;
import Ice.Current;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public final class SessionI extends _SessionDisp
   {
   private static final Log LOG = LogFactory.getLog(SessionI.class);

   SessionI(final String userId)
      {
      _userId = userId;
      }

   public void destroy(final Current current)
      {
      LOG.info("destroying session for user `" + _userId + "'");
      current.adapter.remove(current.id);
      }

   private final String _userId;
   }
