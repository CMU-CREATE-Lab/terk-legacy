// **********************************************************************
//
// Copyright (c) 2003-2005 ZeroC, Inc. All rights reserved.
//
// This copy of Ice is licensed to you under the terms described in the
// ICE_LICENSE file included in this distribution.
//
// **********************************************************************

// Ice version 3.0.1

package Demo;

public final class HelloPrxHelper extends Ice.ObjectPrxHelperBase implements HelloPrx
{
    public void
    sayHello(String from)
    {
	sayHello(from, __defaultContext());
    }

    public void
    sayHello(String from, java.util.Map __ctx)
    {
	int __cnt = 0;
	while(true)
	{
	    try
	    {
		Ice._ObjectDel __delBase = __getDelegate();
		_HelloDel __del = (_HelloDel)__delBase;
		__del.sayHello(from, __ctx);
		return;
	    }
	    catch(IceInternal.NonRepeatable __ex)
	    {
		__rethrowException(__ex.get());
	    }
	    catch(Ice.LocalException __ex)
	    {
		__cnt = __handleException(__ex, __cnt);
	    }
	}
    }

    public static HelloPrx
    checkedCast(Ice.ObjectPrx b)
    {
	HelloPrx d = null;
	if(b != null)
	{
	    try
	    {
		d = (HelloPrx)b;
	    }
	    catch(ClassCastException ex)
	    {
		if(b.ice_isA("::Demo::Hello"))
		{
		    HelloPrxHelper h = new HelloPrxHelper();
		    h.__copyFrom(b);
		    d = h;
		}
	    }
	}
	return d;
    }

    public static HelloPrx
    checkedCast(Ice.ObjectPrx b, java.util.Map ctx)
    {
	HelloPrx d = null;
	if(b != null)
	{
	    try
	    {
		d = (HelloPrx)b;
	    }
	    catch(ClassCastException ex)
	    {
		if(b.ice_isA("::Demo::Hello", ctx))
		{
		    HelloPrxHelper h = new HelloPrxHelper();
		    h.__copyFrom(b);
		    d = h;
		}
	    }
	}
	return d;
    }

    public static HelloPrx
    checkedCast(Ice.ObjectPrx b, String f)
    {
	HelloPrx d = null;
	if(b != null)
	{
	    Ice.ObjectPrx bb = b.ice_newFacet(f);
	    try
	    {
		if(bb.ice_isA("::Demo::Hello"))
		{
		    HelloPrxHelper h = new HelloPrxHelper();
		    h.__copyFrom(bb);
		    d = h;
		}
	    }
	    catch(Ice.FacetNotExistException ex)
	    {
	    }
	}
	return d;
    }

    public static HelloPrx
    checkedCast(Ice.ObjectPrx b, String f, java.util.Map ctx)
    {
	HelloPrx d = null;
	if(b != null)
	{
	    Ice.ObjectPrx bb = b.ice_newFacet(f);
	    try
	    {
		if(bb.ice_isA("::Demo::Hello", ctx))
		{
		    HelloPrxHelper h = new HelloPrxHelper();
		    h.__copyFrom(bb);
		    d = h;
		}
	    }
	    catch(Ice.FacetNotExistException ex)
	    {
	    }
	}
	return d;
    }

    public static HelloPrx
    uncheckedCast(Ice.ObjectPrx b)
    {
	HelloPrx d = null;
	if(b != null)
	{
	    HelloPrxHelper h = new HelloPrxHelper();
	    h.__copyFrom(b);
	    d = h;
	}
	return d;
    }

    public static HelloPrx
    uncheckedCast(Ice.ObjectPrx b, String f)
    {
	HelloPrx d = null;
	if(b != null)
	{
	    Ice.ObjectPrx bb = b.ice_newFacet(f);
	    HelloPrxHelper h = new HelloPrxHelper();
	    h.__copyFrom(bb);
	    d = h;
	}
	return d;
    }

    protected Ice._ObjectDelM
    __createDelegateM()
    {
	return new _HelloDelM();
    }

    protected Ice._ObjectDelD
    __createDelegateD()
    {
	return new _HelloDelD();
    }

    public static void
    __write(IceInternal.BasicStream __os, HelloPrx v)
    {
	__os.writeProxy(v);
    }

    public static HelloPrx
    __read(IceInternal.BasicStream __is)
    {
	Ice.ObjectPrx proxy = __is.readProxy();
	if(proxy != null)
	{
	    HelloPrxHelper result = new HelloPrxHelper();
	    result.__copyFrom(proxy);
	    return result;
	}
	return null;
    }
}
