// **********************************************************************
//
// Copyright (c) 2003-2005 ZeroC, Inc. All rights reserved.
//
// This copy of Ice is licensed to you under the terms described in the
// ICE_LICENSE file included in this distribution.
//
// **********************************************************************

// Ice version 3.0.1

package Demo;

public interface RegistryPrx extends Ice.ObjectPrx
{
    public void add(Ice.Identity id);
    public void add(Ice.Identity id, java.util.Map __ctx);

    public void remove(Ice.Identity id);
    public void remove(Ice.Identity id, java.util.Map __ctx);

    public Ice.ObjectPrx locate(Ice.Identity id);
    public Ice.ObjectPrx locate(Ice.Identity id, java.util.Map __ctx);
}
