// **********************************************************************
//
// Copyright (c) 2003-2005 ZeroC, Inc. All rights reserved.
//
// This copy of Ice is licensed to you under the terms described in the
// ICE_LICENSE file included in this distribution.
//
// **********************************************************************

// Ice version 3.0.1

package Demo;

public final class RegistryPrxHelper extends Ice.ObjectPrxHelperBase implements RegistryPrx
{
    public void
    add(Ice.Identity id)
    {
	add(id, __defaultContext());
    }

    public void
    add(Ice.Identity id, java.util.Map __ctx)
    {
	int __cnt = 0;
	while(true)
	{
	    try
	    {
		Ice._ObjectDel __delBase = __getDelegate();
		_RegistryDel __del = (_RegistryDel)__delBase;
		__del.add(id, __ctx);
		return;
	    }
	    catch(IceInternal.NonRepeatable __ex)
	    {
		__rethrowException(__ex.get());
	    }
	    catch(Ice.LocalException __ex)
	    {
		__cnt = __handleException(__ex, __cnt);
	    }
	}
    }

    public Ice.ObjectPrx
    locate(Ice.Identity id)
    {
	return locate(id, __defaultContext());
    }

    public Ice.ObjectPrx
    locate(Ice.Identity id, java.util.Map __ctx)
    {
	int __cnt = 0;
	while(true)
	{
	    try
	    {
		__checkTwowayOnly("locate");
		Ice._ObjectDel __delBase = __getDelegate();
		_RegistryDel __del = (_RegistryDel)__delBase;
		return __del.locate(id, __ctx);
	    }
	    catch(IceInternal.NonRepeatable __ex)
	    {
		__rethrowException(__ex.get());
	    }
	    catch(Ice.LocalException __ex)
	    {
		__cnt = __handleException(__ex, __cnt);
	    }
	}
    }

    public void
    remove(Ice.Identity id)
    {
	remove(id, __defaultContext());
    }

    public void
    remove(Ice.Identity id, java.util.Map __ctx)
    {
	int __cnt = 0;
	while(true)
	{
	    try
	    {
		Ice._ObjectDel __delBase = __getDelegate();
		_RegistryDel __del = (_RegistryDel)__delBase;
		__del.remove(id, __ctx);
		return;
	    }
	    catch(IceInternal.NonRepeatable __ex)
	    {
		__rethrowException(__ex.get());
	    }
	    catch(Ice.LocalException __ex)
	    {
		__cnt = __handleException(__ex, __cnt);
	    }
	}
    }

    public static RegistryPrx
    checkedCast(Ice.ObjectPrx b)
    {
	RegistryPrx d = null;
	if(b != null)
	{
	    try
	    {
		d = (RegistryPrx)b;
	    }
	    catch(ClassCastException ex)
	    {
		if(b.ice_isA("::Demo::Registry"))
		{
		    RegistryPrxHelper h = new RegistryPrxHelper();
		    h.__copyFrom(b);
		    d = h;
		}
	    }
	}
	return d;
    }

    public static RegistryPrx
    checkedCast(Ice.ObjectPrx b, java.util.Map ctx)
    {
	RegistryPrx d = null;
	if(b != null)
	{
	    try
	    {
		d = (RegistryPrx)b;
	    }
	    catch(ClassCastException ex)
	    {
		if(b.ice_isA("::Demo::Registry", ctx))
		{
		    RegistryPrxHelper h = new RegistryPrxHelper();
		    h.__copyFrom(b);
		    d = h;
		}
	    }
	}
	return d;
    }

    public static RegistryPrx
    checkedCast(Ice.ObjectPrx b, String f)
    {
	RegistryPrx d = null;
	if(b != null)
	{
	    Ice.ObjectPrx bb = b.ice_newFacet(f);
	    try
	    {
		if(bb.ice_isA("::Demo::Registry"))
		{
		    RegistryPrxHelper h = new RegistryPrxHelper();
		    h.__copyFrom(bb);
		    d = h;
		}
	    }
	    catch(Ice.FacetNotExistException ex)
	    {
	    }
	}
	return d;
    }

    public static RegistryPrx
    checkedCast(Ice.ObjectPrx b, String f, java.util.Map ctx)
    {
	RegistryPrx d = null;
	if(b != null)
	{
	    Ice.ObjectPrx bb = b.ice_newFacet(f);
	    try
	    {
		if(bb.ice_isA("::Demo::Registry", ctx))
		{
		    RegistryPrxHelper h = new RegistryPrxHelper();
		    h.__copyFrom(bb);
		    d = h;
		}
	    }
	    catch(Ice.FacetNotExistException ex)
	    {
	    }
	}
	return d;
    }

    public static RegistryPrx
    uncheckedCast(Ice.ObjectPrx b)
    {
	RegistryPrx d = null;
	if(b != null)
	{
	    RegistryPrxHelper h = new RegistryPrxHelper();
	    h.__copyFrom(b);
	    d = h;
	}
	return d;
    }

    public static RegistryPrx
    uncheckedCast(Ice.ObjectPrx b, String f)
    {
	RegistryPrx d = null;
	if(b != null)
	{
	    Ice.ObjectPrx bb = b.ice_newFacet(f);
	    RegistryPrxHelper h = new RegistryPrxHelper();
	    h.__copyFrom(bb);
	    d = h;
	}
	return d;
    }

    protected Ice._ObjectDelM
    __createDelegateM()
    {
	return new _RegistryDelM();
    }

    protected Ice._ObjectDelD
    __createDelegateD()
    {
	return new _RegistryDelD();
    }

    public static void
    __write(IceInternal.BasicStream __os, RegistryPrx v)
    {
	__os.writeProxy(v);
    }

    public static RegistryPrx
    __read(IceInternal.BasicStream __is)
    {
	Ice.ObjectPrx proxy = __is.readProxy();
	if(proxy != null)
	{
	    RegistryPrxHelper result = new RegistryPrxHelper();
	    result.__copyFrom(proxy);
	    return result;
	}
	return null;
    }
}
