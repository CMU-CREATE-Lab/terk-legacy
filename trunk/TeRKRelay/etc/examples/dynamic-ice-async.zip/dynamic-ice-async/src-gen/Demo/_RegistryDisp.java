// **********************************************************************
//
// Copyright (c) 2003-2005 ZeroC, Inc. All rights reserved.
//
// This copy of Ice is licensed to you under the terms described in the
// ICE_LICENSE file included in this distribution.
//
// **********************************************************************

// Ice version 3.0.1

package Demo;

public abstract class _RegistryDisp extends Ice.ObjectImpl implements Registry
{
    protected void
    ice_copyStateFrom(Ice.Object __obj)
	throws java.lang.CloneNotSupportedException
    {
	throw new java.lang.CloneNotSupportedException();
    }

    public static final String[] __ids =
    {
	"::Demo::Registry",
	"::Ice::Object"
    };

    public boolean
    ice_isA(String s)
    {
	return java.util.Arrays.binarySearch(__ids, s) >= 0;
    }

    public boolean
    ice_isA(String s, Ice.Current __current)
    {
	return java.util.Arrays.binarySearch(__ids, s) >= 0;
    }

    public String[]
    ice_ids()
    {
	return __ids;
    }

    public String[]
    ice_ids(Ice.Current __current)
    {
	return __ids;
    }

    public String
    ice_id()
    {
	return __ids[0];
    }

    public String
    ice_id(Ice.Current __current)
    {
	return __ids[0];
    }

    public static String
    ice_staticId()
    {
	return __ids[0];
    }

    public final void
    add(Ice.Identity id)
    {
	add(id, null);
    }

    public final Ice.ObjectPrx
    locate(Ice.Identity id)
    {
	return locate(id, null);
    }

    public final void
    remove(Ice.Identity id)
    {
	remove(id, null);
    }

    public static IceInternal.DispatchStatus
    ___add(Registry __obj, IceInternal.Incoming __inS, Ice.Current __current)
    {
	__checkMode(Ice.OperationMode.Normal, __current.mode);
	IceInternal.BasicStream __is = __inS.is();
	Ice.Identity id;
	id = new Ice.Identity();
	id.__read(__is);
	__obj.add(id, __current);
	return IceInternal.DispatchStatus.DispatchOK;
    }

    public static IceInternal.DispatchStatus
    ___remove(Registry __obj, IceInternal.Incoming __inS, Ice.Current __current)
    {
	__checkMode(Ice.OperationMode.Normal, __current.mode);
	IceInternal.BasicStream __is = __inS.is();
	Ice.Identity id;
	id = new Ice.Identity();
	id.__read(__is);
	__obj.remove(id, __current);
	return IceInternal.DispatchStatus.DispatchOK;
    }

    public static IceInternal.DispatchStatus
    ___locate(Registry __obj, IceInternal.Incoming __inS, Ice.Current __current)
    {
	__checkMode(Ice.OperationMode.Normal, __current.mode);
	IceInternal.BasicStream __is = __inS.is();
	IceInternal.BasicStream __os = __inS.os();
	Ice.Identity id;
	id = new Ice.Identity();
	id.__read(__is);
	Ice.ObjectPrx __ret = __obj.locate(id, __current);
	__os.writeProxy(__ret);
	return IceInternal.DispatchStatus.DispatchOK;
    }

    private final static String[] __all =
    {
	"add",
	"ice_id",
	"ice_ids",
	"ice_isA",
	"ice_ping",
	"locate",
	"remove"
    };

    public IceInternal.DispatchStatus
    __dispatch(IceInternal.Incoming in, Ice.Current __current)
    {
	int pos = java.util.Arrays.binarySearch(__all, __current.operation);
	if(pos < 0)
	{
	    return IceInternal.DispatchStatus.DispatchOperationNotExist;
	}

	switch(pos)
	{
	    case 0:
	    {
		return ___add(this, in, __current);
	    }
	    case 1:
	    {
		return ___ice_id(this, in, __current);
	    }
	    case 2:
	    {
		return ___ice_ids(this, in, __current);
	    }
	    case 3:
	    {
		return ___ice_isA(this, in, __current);
	    }
	    case 4:
	    {
		return ___ice_ping(this, in, __current);
	    }
	    case 5:
	    {
		return ___locate(this, in, __current);
	    }
	    case 6:
	    {
		return ___remove(this, in, __current);
	    }
	}

	assert(false);
	return IceInternal.DispatchStatus.DispatchOperationNotExist;
    }
}
