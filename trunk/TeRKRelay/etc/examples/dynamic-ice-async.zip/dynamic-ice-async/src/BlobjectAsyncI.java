import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import Ice.AMD_Object_ice_invoke;
import Ice.AMI_Object_ice_invoke;
import Ice.BlobjectAsync;
import Ice.Connection;
import Ice.Current;
import Ice.Identity;
import Ice.ObjectAdapter;
import Ice.ObjectNotExistException;
import Ice.ObjectPrx;

final class BlobjectAsyncI extends BlobjectAsync
   {
   private final ObjectAdapter adapter;
   private final Map<Identity, ObjectPrx> objects = Collections.synchronizedMap(new HashMap<Identity, ObjectPrx>());

   BlobjectAsyncI(final ObjectAdapter adapter)
      {
      this.adapter = adapter;
      }

   public void ice_invoke_async(final AMD_Object_ice_invoke amdCallback, final byte[] inParams, final Current current)
      {
      ObjectPrx proxy = objects.get(current.id);
      if (proxy != null)
         {
         if (current.facet.length() > 0)
            {
            proxy = proxy.ice_newFacet(current.facet);
            }
         final AMI_Object_ice_invoke amiCallback = new AsyncCallback(amdCallback);
         proxy.ice_invoke_async(amiCallback, current.operation, current.mode, inParams, current.ctx);
         return;
         }

      final ObjectNotExistException ex = new ObjectNotExistException(current.id, current.facet, current.operation);
      amdCallback.ice_exception(ex);
      }

   void add(final Identity id, final Connection connection)
      {
      objects.put(id, connection.createProxy(id));
      }

   void remove(final Identity id)
      {
      objects.remove(id);
      }

   ObjectPrx locate(final Identity id)
      {
      final ObjectPrx objectPrx = objects.get(id);
      if (objectPrx != null)
         {
         return adapter.createProxy(id);
         }
      return null;
      }
   }
