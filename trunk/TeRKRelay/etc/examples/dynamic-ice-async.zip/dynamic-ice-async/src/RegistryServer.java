import Ice.Application;
import Ice.ObjectAdapter;
import Ice.Util;

public final class RegistryServer extends Application
   {
   public int run(final String[] args)
      {
      // Create the object adapter (the endpoints for the object adapter are taken from the property name.Endpoints).
      final ObjectAdapter adapter = communicator().createObjectAdapter("Registry");
      final BlobjectAsyncI blobjectAsyncI = new BlobjectAsyncI(adapter);
      adapter.add(new RegistryI(blobjectAsyncI), Util.stringToIdentity("registry"));
      adapter.addServantLocator(new LocatorI(blobjectAsyncI), "");
      adapter.activate();

      communicator().waitForShutdown();

      return 0;
      }

   public static void main(final String[] args)
      {
      final RegistryServer registryServer = new RegistryServer();
      final int status = registryServer.main("RegistryServer", args, "config.properties");
      System.exit(status);
      }
   }
