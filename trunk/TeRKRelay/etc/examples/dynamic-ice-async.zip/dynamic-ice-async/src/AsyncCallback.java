import Ice.AMD_Object_ice_invoke;
import Ice.AMI_Object_ice_invoke;
import Ice.LocalException;

final class AsyncCallback extends AMI_Object_ice_invoke
   {
   private final AMD_Object_ice_invoke amdCallback;

   AsyncCallback(final AMD_Object_ice_invoke amdCallback)
      {
      this.amdCallback = amdCallback;
      }

   public void ice_response(final boolean ok, final byte[] outParams)
      {
      amdCallback.ice_response(ok, outParams);
      }

   public void ice_exception(final LocalException ex)
      {
      amdCallback.ice_exception(ex);
      }
   }
