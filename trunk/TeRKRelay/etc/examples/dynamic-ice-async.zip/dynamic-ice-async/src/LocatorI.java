import Ice.Current;
import Ice.LocalObject;
import Ice.LocalObjectHolder;
import Ice.LocalObjectImpl;
import Ice.Object;
import Ice.ServantLocator;

final class LocatorI extends LocalObjectImpl implements ServantLocator
   {
   private final BlobjectAsyncI blobjectAsyncI;

   LocatorI(final BlobjectAsyncI blobjectAsyncI)
      {
      this.blobjectAsyncI = blobjectAsyncI;
      }

   public Object locate(final Current current, final LocalObjectHolder cookie)
      {
      IceUtil.printCurrent("LocatorI.locate()", current);
      return blobjectAsyncI;
      }

   public void finished(final Current current, final Object servant, final LocalObject cookie)
      {
      IceUtil.printCurrent("LocatorI.finished()", current);
      // Nothing to do.
      }

   public void deactivate(final String category)
      {
      System.out.println("LocatorI.deactivate() -- category=[" + category + "]");
      // Nothing to do.
      }
   }
