import Demo._RegistryDisp;
import Ice.Current;
import Ice.Identity;
import Ice.ObjectPrx;

final class RegistryI extends _RegistryDisp
   {
   private final BlobjectAsyncI blobjectAsyncI;

   RegistryI(final BlobjectAsyncI blobjectAsyncI)
      {
      this.blobjectAsyncI = blobjectAsyncI;
      }

   public void add(final Identity id, final Current current)
      {
      blobjectAsyncI.add(id, current.con);
      }

   public void remove(final Identity id, final Current current)
      {
      blobjectAsyncI.remove(id);
      }

   public ObjectPrx locate(final Identity id, final Current current)
      {
      return blobjectAsyncI.locate(id);
      }
   }
