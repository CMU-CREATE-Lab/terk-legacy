import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import Chat.ChatCallbackPrx;
import Chat.ChatCallbackPrxHelper;
import Chat.ChatSessionPrx;
import Chat.ChatSessionPrxHelper;
import Glacier2.CannotCreateSessionException;
import Glacier2.PermissionDeniedException;
import Glacier2.RouterPrx;
import Glacier2.RouterPrxHelper;
import Glacier2.SessionNotExistException;
import Ice.Application;
import Ice.Identity;
import Ice.LocalException;
import Ice.ObjectAdapter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ChatClient extends Application
   {
   private static final Log LOG = LogFactory.getLog(ChatClient.class);
   private static final String QUIT_COMMAND = "/quit";

   public int run(final String[] args)
      {
      final Map<String, String> contextMap = new HashMap<String, String>(1);
      contextMap.put("client_type", "human");

      final Ice.RouterPrx defaultRouter = communicator().getDefaultRouter();
      if (defaultRouter == null)
         {
         LOG.error("no default router set");
         return 1;
         }

      final RouterPrx router = RouterPrxHelper.checkedCast(defaultRouter);
      if (router == null)
         {
         LOG.error("configured router is not a Glacier2 router");
         return 1;
         }

      final BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
      ChatSessionPrx chatSessionPrx;
      while (true)
         {
         LOG.info("This demo accepts any user-id / password combination.");

         try
            {
            final String id;
            print("user id: ");
            id = in.readLine();

            final String pw;
            print("password: ");
            pw = in.readLine();

            try
               {
               chatSessionPrx = ChatSessionPrxHelper.uncheckedCast(router.createSession(id, pw, contextMap));
               break;
               }
            catch (PermissionDeniedException ex)
               {
               LOG.error("permission denied:\n" + ex.reason);
               }
            catch (CannotCreateSessionException ex)
               {
               LOG.error("cannot create session:\n" + ex.reason);
               }
            }
         catch (IOException ex)
            {
            ex.printStackTrace();
            }
         }

      // todo: figure out a way to store the pinger sleep time--IceGrid?
      final IceSessionPinger iceSessionPinger = new IceSessionPinger(50, chatSessionPrx);
      iceSessionPinger.start();

      final String category = router.getServerProxy().ice_getIdentity().category;
      final Identity callbackReceiverIdent = new Identity();
      callbackReceiverIdent.name = "callbackReceiver";
      callbackReceiverIdent.category = category;

      final ObjectAdapter adapter = communicator().createObjectAdapter("Chat.Client");
      final ChatCallbackPrx callback = ChatCallbackPrxHelper.uncheckedCast(adapter.add(new ChatCallbackServant(), callbackReceiverIdent));
      adapter.activate();

      chatSessionPrx.setCallback(callback);

      menu();

      try
         {
         String line;

         do
            {
            print("==> ");
            line = in.readLine();
            if (line == null)
               {
               break;
               }
            else if (line.startsWith("/") && !QUIT_COMMAND.equals(line))
               {
               menu();
               }
            else if (line.length() > 0)
               {
               chatSessionPrx.sendMessage(line);
               }
            }
         while (!QUIT_COMMAND.equals(line));
         }
      catch (IOException ex)
         {
         ex.printStackTrace();
         }
      catch (LocalException ex)
         {
         ex.printStackTrace();
         }
      finally
         {
         iceSessionPinger.stop();

         try
            {
            router.destroySession();
            }
         catch (SessionNotExistException e)
            {
            LOG.error("SessionNotExistException while trying to destroy the session", e);
            }
         }

      return 0;
      }

   private void print(final String str)
      {
      System.out.print(str);
      System.out.flush();
      }

   private void menu()
      {
      LOG.info("enter " + QUIT_COMMAND + " to exit.");
      }

   public static void main(final String[] args)
      {
      final ChatClient app = new ChatClient();
      final int status = app.main("Client", args, "config.client.properties");
      System.exit(status);
      }
   }