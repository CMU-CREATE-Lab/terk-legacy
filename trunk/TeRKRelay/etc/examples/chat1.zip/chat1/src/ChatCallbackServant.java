import Chat._ChatCallbackDisp;
import Ice.Current;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author Chris Bartley (bartley@cmu.edu)
 */
final class ChatCallbackServant extends _ChatCallbackDisp
   {
   private static final Log LOG = LogFactory.getLog(ChatCallbackServant.class);

   public void handleMessage(final String data, final Current current)
      {
      IceUtil.printCurrent("ChatCallbackServant.handleMessage()", current);
      LOG.info(data);
      }
   }
