import Ice.Application;
import Ice.ObjectAdapter;
import Ice.Util;

public final class ChatServer extends Application
   {
   public int run(final String[] args)
      {
      final ObjectAdapter adapter = communicator().createObjectAdapter("ChatServer");
      adapter.add(new ChatServerPermissionsVerifierServant(), Util.stringToIdentity("TeRKPermissionsVerifier"));
      adapter.add(new ChatSessionManagerServant(), Util.stringToIdentity("TeRKSessionManager"));
      adapter.activate();
      communicator().waitForShutdown();
      return 0;
      }

   public static void main(final String[] args)
      {
      final ChatServer app = new ChatServer();
      final int status = app.main("Server", args, "config.server.properties");
      System.exit(status);
      }
   }
