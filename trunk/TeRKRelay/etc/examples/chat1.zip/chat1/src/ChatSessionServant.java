import Chat.ChatCallbackPrx;
import Chat._ChatSessionDisp;
import Ice.Current;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

final class ChatSessionServant extends _ChatSessionDisp
   {
   private static final Log LOG = LogFactory.getLog(ChatSessionServant.class);

   private final String _userId;
   private ChatCallbackPrx _callback;

   ChatSessionServant(final String userId)
      {
      _userId = userId;
      }

   public void setCallback(final ChatCallbackPrx callback, final Current current)
      {
      IceUtil.printCurrent("ChatSessionServant.setCallback()", current);
      _callback = callback;
      ChatRoom.getInstance().message(_userId + " has entered the chat room.");
      ChatRoom.getInstance().enter(callback);
      }

   public void sendMessage(final String data, final Current current)
      {
      IceUtil.printCurrent("ChatSessionServant.sendMessage()", current);
      ChatRoom.getInstance().message(_userId + " says: " + data);
      }

   public void destroy(final Current current)
      {
      IceUtil.printCurrent("ChatSessionServant.destroy()", current);
      LOG.info("destroying session for user [" + _userId + "]");
      if (_callback != null)
         {
         ChatRoom.getInstance().leave(_callback);
         _callback = null;
         ChatRoom.getInstance().message(_userId + " has left the chat room.");
         }
      current.adapter.remove(current.id);
      }
   }
