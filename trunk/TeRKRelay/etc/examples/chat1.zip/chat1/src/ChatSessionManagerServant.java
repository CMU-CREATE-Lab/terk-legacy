import Glacier2.Session;
import Glacier2.SessionPrx;
import Glacier2.SessionPrxHelper;
import Glacier2._SessionManagerDisp;
import Ice.Current;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author Chris Bartley (bartley@cmu.edu)
 */
final class ChatSessionManagerServant extends _SessionManagerDisp
   {
   private static final Log LOG = LogFactory.getLog(ChatSessionManagerServant.class);

   public SessionPrx create(final String userId, final Current current)
      {
      IceUtil.printCurrent("ChatSessionManagerServant.create()", current);
      LOG.info("creating session for user [" + userId + "]");
      final Session session = new ChatSessionServant(userId);
      return SessionPrxHelper.uncheckedCast(current.adapter.addWithUUID(session));
      }
   }
