import java.util.Iterator;
import Ice.Current;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author Chris Bartley (bartley@cmu.edu)
 */
final class IceUtil
   {
   private static final Log LOG = LogFactory.getLog(IceUtil.class);
   private static final String LINE_SEPARATOR = System.getProperty("line.separator");
   private static final String PADDING = "   ";

   static void printCurrent(final String name, final Current current)
      {
      final StringBuffer s = new StringBuffer(name + ":" + LINE_SEPARATOR);
      s.append(PADDING).append("current.adapter.getName() = ").append(current.adapter.getName()).append(LINE_SEPARATOR);
      s.append(PADDING).append("current.con.timeout()     = ").append(current.con.timeout()).append(LINE_SEPARATOR);
      s.append(PADDING).append("current.con.type()        = ").append(current.con.type()).append(LINE_SEPARATOR);
      s.append(PADDING).append("current.facet             = ").append(current.facet).append(LINE_SEPARATOR);
      s.append(PADDING).append("current.id.name           = ").append(current.id.name).append(LINE_SEPARATOR);
      s.append(PADDING).append("current.id.category       = ").append(current.id.category).append(LINE_SEPARATOR);
      s.append(PADDING).append("current.mode.toString()   = ").append(current.mode.toString()).append(LINE_SEPARATOR);
      s.append(PADDING).append("current.mode.value()      = ").append(current.mode.value()).append(LINE_SEPARATOR);
      s.append(PADDING).append("current.operation         = ").append(current.operation).append(LINE_SEPARATOR);
      s.append(PADDING).append("current.ctx contains ").append(current.ctx == null ? 0 : current.ctx.size()).append(" elements:").append(LINE_SEPARATOR);
      if ((current.ctx != null) && (!current.ctx.isEmpty()))
         {
         for (final Iterator iterator = current.ctx.keySet().iterator(); iterator.hasNext();)
            {
            final Object key = iterator.next();
            final Object val = current.ctx.get(key);
            s.append(PADDING).append(PADDING).append("[").append(key).append("|").append(val).append("]").append(LINE_SEPARATOR);
            }
         }

      LOG.debug(s);
      }

   private IceUtil()
      {
      // private to prevent instantiation
      }
   }
