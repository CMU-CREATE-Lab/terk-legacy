import Glacier2.SessionPrx;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author Chris Bartley (bartley@cmu.edu)
 */
public final class IceSessionPinger extends ControllableThread
   {
   private static final Log LOG = LogFactory.getLog(IceSessionPinger.class);

   private final int sleepTime;
   private final SessionPrx sessionPrx;

   public IceSessionPinger(final int sleepTimeInSeconds, final SessionPrx sessionPrx)
      {
      this.sleepTime = sleepTimeInSeconds * 1000;
      this.sessionPrx = sessionPrx;
      }

   protected int getSleepTime()
      {
      return sleepTime;
      }

   protected void performLoopedBehavior()
      {
      if (sessionPrx != null)
         {
         try
            {
            sessionPrx.ice_ping();
            }
         catch (Exception e)
            {
            LOG.error("Exception while trying to ping the session.  Aborting pinger.", e);
            stop();
            }
         }
      }
   }
