import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author Chris Bartley (bartley@cmu.edu)
 */
public abstract class ControllableThread
   {
   private static final Log LOG = LogFactory.getLog(ControllableThread.class);
   private static final int DEFAULT_SLEEP_TIME_MILLISECONDS = 1;

   private final class ControlledThread extends Thread
      {
      public final void run()
         {
         isRunning = true;

         performStartupBehavior();

         while (isRunning() && loopCondition())
            {
            if (!isPaused)
               {
               performLoopedBehavior();
               }

            try
               {
               sleep(getSleepTime());
               }
            catch (InterruptedException e)
               {
               e.printStackTrace();
               }
            }

         performShutdownBehavior();

         isRunning = false;
         }
      }

   private final Thread controlledThread = new ControlledThread();
   private boolean isRunning = false;
   private boolean isPaused = false;

   /** Starts the thread. */
   public final void start()
      {
      if (isRunning())
         {
         LOG.warn("Aborting start() since the thread has already been started.");
         return;
         }

      controlledThread.start();
      }

   /** Stops the thread. */
   public final void stop()
      {
      isRunning = false;
      }

   /** Pauses the thread.  In truth, the thread still continues to run, but the body of its loop is not executed. */
   public final void pause()
      {
      isPaused = true;
      }

   /** Resumes the thread. */
   public final void resume()
      {
      isPaused = false;
      }

   /** Returns <code>true</code> if the thread is currently running; <code>false</code> otherwise. */
   public final boolean isRunning()
      {
      return isRunning;
      }

   /**
    * Returns the amount of time (in milliseconds) the thread should sleep during each iteration of the loop.  Defaults
    * to <code>1</code>.
    */
   protected int getSleepTime()
      {
      return DEFAULT_SLEEP_TIME_MILLISECONDS;
      }

   /** Executes the behavior to be performed before the loop begins.  Defaults to doing nothing. */
   protected void performStartupBehavior()
      {
      }

   /** Defines whether the loop should continue.  Defaults to always returning <code>true</code>. */
   protected boolean loopCondition()
      {
      return true;
      }

   /** Executes the behavior to be performed within the loop.  Defaults to doing nothing. */
   protected void performLoopedBehavior()
      {
      }

   /** Executes the behavior to be performed after the loop ends.  Defaults to doing nothing. */
   protected void performShutdownBehavior()
      {
      }
   }
