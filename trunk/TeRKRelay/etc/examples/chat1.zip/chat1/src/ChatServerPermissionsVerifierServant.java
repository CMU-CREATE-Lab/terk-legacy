import Glacier2._PermissionsVerifierDisp;
import Ice.StringHolder;
import Ice.Current;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author Chris Bartley (bartley@cmu.edu)
 */
final class ChatServerPermissionsVerifierServant extends _PermissionsVerifierDisp
   {
   private static final Log LOG = LogFactory.getLog(ChatServerPermissionsVerifierServant.class);

   public boolean checkPermissions(final String userId, final String password, final StringHolder reason, final Current current)
      {
      IceUtil.printCurrent("ChatServerPermissionsVerifierServant.checkPermissions()", current);
      LOG.info("verified user [" + userId + "] with password  [" + password + "]");
      return true;
      }
   }
