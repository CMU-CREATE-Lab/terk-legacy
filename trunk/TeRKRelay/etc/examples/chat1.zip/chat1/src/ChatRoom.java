import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import Chat.ChatCallbackPrx;
import Chat.ChatCallbackPrxHelper;
import Ice.LocalException;
import Ice.Util;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author Chris Bartley (bartley@cmu.edu)
 */
final class ChatRoom
   {
   private static final Log LOG = LogFactory.getLog(ChatRoom.class);
   private static final ChatRoom INSTANCE = new ChatRoom();

   static ChatRoom getInstance()
      {
      return INSTANCE;
      }

   private final List<ChatCallbackPrx> members = Collections.synchronizedList(new ArrayList<ChatCallbackPrx>());

   private ChatRoom()
      {
      // private to prevent instantiation
      }

   void enter(final ChatCallbackPrx callback)
      {
      // set up the context so that Glacier2 makes one-way invocations back to the clients.  "This provides maximum
      // throughput and avoids problems due to network latency or malicious clients."  See ZeroC's Connections
      // newsletter, issue #2 for more info.
      final Map contextMap = new HashMap();
      contextMap.put("_fwd", "Oz");
      members.add(ChatCallbackPrxHelper.uncheckedCast(callback.ice_newContext(contextMap)));
      }

   void leave(final ChatCallbackPrx callback)
      {
      synchronized (members)
         {
         for (final ChatCallbackPrx member : members)
            {
            if (Util.proxyIdentityCompare(callback, member) == 0)
               {
               members.remove(member);
               break;
               }
            }
         }
      }

   void message(final String data)
      {
      synchronized (members)
         {
         for (final ChatCallbackPrx member : members)
            {
            try
               {
               member.handleMessage(data);
               }
            catch (LocalException e)
               {
               LOG.error("LocalException while trying to send message to user [" + member.ice_getIdentity() + "]", e);
               }
            }
         }
      }
   }

