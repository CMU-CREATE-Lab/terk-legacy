BUILDING THE APPLICATION
------------------------
* Make sure you have an environment variable named ICE_HOME which points to
  Ice's home directory.  For example, on my system, I have the following:

     ICE_HOME=C:\Ice-3.0.1

* Open a command prompt and change the working directory to this directory
* Type "ant"

RUNNING THE APPLICATION
-----------------------
* Open three command prompt windows, and change the working directories of
  each to the "bin" directory which was created during the build.

* In the first command prompt window, start the registry service by running
  the RegistryServer.bat script:

> RegistryServer.bat

* In the second command prompt window, start a peer and give it a name:

> Client.bat PeerA

* Finally, in the third command prompt window, start another peer and pass
  the name of the first peer:

> Client.bat PeerB PeerA

* The first client should print "PeerB says hello.".
