import Demo._RegistryDisp;
import Ice.Current;
import Ice.Identity;
import Ice.ObjectPrx;

final class RegistryI extends _RegistryDisp
   {
   private final BlobjectI blobjectI;

   RegistryI(final BlobjectI blobjectI)
      {
      this.blobjectI = blobjectI;
      }

   public void add(final Identity id, final Current current)
      {
      blobjectI.add(id, current.con);
      }

   public void remove(final Identity id, final Current current)
      {
      blobjectI.remove(id);
      }

   public ObjectPrx locate(final Identity id, final Current current)
      {
      return blobjectI.locate(id);
      }
   }
