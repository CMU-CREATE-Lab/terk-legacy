import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import Ice.Blobject;
import Ice.ByteSeqHolder;
import Ice.Connection;
import Ice.Current;
import Ice.Identity;
import Ice.ObjectAdapter;
import Ice.ObjectNotExistException;
import Ice.ObjectPrx;

final class BlobjectI extends Blobject
   {
   private final ObjectAdapter adapter;
   private final Map<Identity, ObjectPrx> objects = Collections.synchronizedMap(new HashMap<Identity, ObjectPrx>());

   BlobjectI(final ObjectAdapter adapter)
      {
      this.adapter = adapter;
      }

   public boolean ice_invoke(final byte[] inParams, final ByteSeqHolder outParams, final Current current)
      {
      ObjectPrx proxy = objects.get(current.id);
      if (proxy != null)
         {
         if (current.facet.length() > 0)
            {
            proxy = proxy.ice_newFacet(current.facet);
            }
         return proxy.ice_invoke(current.operation, current.mode, inParams, outParams, current.ctx);
         }
      throw new ObjectNotExistException(current.id, current.facet, current.operation);
      }

   void add(final Identity id, final Connection connection)
      {
      objects.put(id, connection.createProxy(id));
      }

   void remove(final Identity id)
      {
      objects.remove(id);
      }

   ObjectPrx locate(final Identity id)
      {
      final ObjectPrx objectPrx = objects.get(id);
      if (objectPrx != null)
         {
         return adapter.createProxy(id);
         }
      return null;
      }
   }
