import Ice.Current;
import Ice.LocalObject;
import Ice.LocalObjectHolder;
import Ice.LocalObjectImpl;
import Ice.Object;
import Ice.ServantLocator;

final class LocatorI extends LocalObjectImpl implements ServantLocator
   {
   private final BlobjectI blobjectI;

   LocatorI(final BlobjectI blobjectI)
      {
      this.blobjectI = blobjectI;
      }

   public Object locate(final Current curr, final LocalObjectHolder cookie)
      {
      return blobjectI;
      }

   public void finished(final Current curr, final Object servant, final LocalObject cookie)
      {
      // Nothing to do.
      }

   public void deactivate(final String category)
      {
      // Nothing to do.
      }
   }
