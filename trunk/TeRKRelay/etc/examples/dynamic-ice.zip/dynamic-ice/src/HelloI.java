import Demo._HelloDisp;
import Ice.Current;

final class HelloI extends _HelloDisp
   {
   public void sayHello(final String from, final Current current)
      {
      System.out.println(from + " says hello");
      }
   }
