import Demo.HelloPrx;
import Demo.HelloPrxHelper;
import Demo.RegistryPrx;
import Demo.RegistryPrxHelper;
import Ice.Application;
import Ice.Identity;
import Ice.ObjectAdapter;
import Ice.ObjectPrx;
import Ice.Properties;
import Ice.Util;

@SuppressWarnings({"UseOfSystemOutOrSystemErr"})
public final class Client extends Application
   {
   public int run(final String[] args)
      {
      if (args.length < 1)
         {
         System.err.println("Usage: appname NAME [PEERNAME]");
         return -1;
         }

      final String name = args[0];
      final String peer = args.length > 1 ? args[1] : null;

      final Properties properties = communicator().getProperties();
      final String proxyProperty = "Registry.Proxy";
      final String proxy = properties.getProperty(proxyProperty);
      if (proxy == null || proxy.length() <= 0)
         {
         System.err.println("Property " + proxyProperty + " not set!");
         return -1;
         }

      final RegistryPrx registryPrx = RegistryPrxHelper.checkedCast(communicator().stringToProxy(proxy));
      if (registryPrx == null)
         {
         System.err.println("Invalid proxy!");
         return -1;
         }

      final ObjectAdapter adapter = communicator().createObjectAdapterWithEndpoints("Client", "tcp");
      final Identity ident = Util.stringToIdentity(name);
      adapter.add(new HelloI(), ident);
      adapter.activate();

      registryPrx.ice_connection().setAdapter(adapter);
      registryPrx.add(ident);

      if (peer != null)
         {
         final ObjectPrx peerProxy = registryPrx.locate(Util.stringToIdentity(peer));
         if (peerProxy != null)
            {
            final HelloPrx hello = HelloPrxHelper.uncheckedCast(peerProxy);
            hello.sayHello(name);
            }
         else
            {
            System.err.println("No peer found matching [" + peer + "]");
            return -1;
            }
         }

      communicator().waitForShutdown();

      return 0;
      }

   public static void main(final String[] args)
      {
      final Client app = new Client();
      final int status = app.main("Client", args, "config.properties");
      System.exit(status);
      }
   }