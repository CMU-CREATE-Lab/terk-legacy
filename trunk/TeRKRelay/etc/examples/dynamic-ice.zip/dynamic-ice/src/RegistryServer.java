import Ice.Application;
import Ice.ObjectAdapter;
import Ice.Util;

public final class RegistryServer extends Application
   {
   public int run(final String[] args)
      {
      final ObjectAdapter adapter = communicator().createObjectAdapter("Registry");
      final BlobjectI blobjectI = new BlobjectI(adapter);
      adapter.add(new RegistryI(blobjectI), Util.stringToIdentity("registry"));
      adapter.addServantLocator(new LocatorI(blobjectI), "");
      adapter.activate();

      communicator().waitForShutdown();

      return 0;
      }

   public static void main(final String[] args)
      {
      final RegistryServer registryServer = new RegistryServer();
      final int status = registryServer.main("RegistryServer", args, "config.properties");
      System.exit(status);
      }
   }
